
struct nlop_s;
extern struct nlop_s* nlop_exp_create(int N, const long dims[N], const complex float* enc);

