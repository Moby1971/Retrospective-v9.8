
struct nlop_s;
extern struct nlop_s* nlop_zexp_create(int N, const long dims[N]);
extern struct nlop_s* nlop_zlog_create(int N, const long dims[N]);

