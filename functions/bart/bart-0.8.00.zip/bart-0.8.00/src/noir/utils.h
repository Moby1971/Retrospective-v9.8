
#include <complex.h>

extern void noir_calc_weights(double a, double b, const long dims[3], complex float* dst);


