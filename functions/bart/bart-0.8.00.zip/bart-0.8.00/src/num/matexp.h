
#include <complex.h>

extern void mat_exp(int N, float t, float out[N][N], const float in[N][N]);

