
#include <complex.h>

extern void zsort(int N, complex float tmp[N]);
extern complex float zselect(int N, int k, const complex float tmp[N]);

