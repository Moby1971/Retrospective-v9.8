


extern double bessel_i0(double x);
extern double Si_power(double x);
extern double Si(double x);
