


extern int dicom_write(const char* name, int cols, int rows, long inum, const unsigned char* img);

