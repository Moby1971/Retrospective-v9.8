
extern int main_real(int argc, char* argv[argc]);

int main(int argc, char* argv[argc])
{
	return main_real(argc, argv);
}

