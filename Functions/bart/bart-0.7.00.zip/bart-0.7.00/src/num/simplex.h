
extern void simplex(unsigned int D, unsigned int N, float x[N], const float c[N], const float b[D], const float A[D][N]);


