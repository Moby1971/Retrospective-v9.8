
extern float gradient_form(const float qf[3], float phi);
extern void fit_quadratic_form(float qf[3], unsigned int N, const float phi[N], const float v[N]);

