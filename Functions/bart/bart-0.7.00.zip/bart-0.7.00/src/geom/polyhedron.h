
extern double polyhedron_vol(int N, const double tri[N][3][3]);


