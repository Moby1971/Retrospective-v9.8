
struct nlop_s;
extern float nlop_test_derivative(const struct nlop_s* op);

