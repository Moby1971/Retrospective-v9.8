
extern complex float coil(float x[3], unsigned int N, unsigned int i);

